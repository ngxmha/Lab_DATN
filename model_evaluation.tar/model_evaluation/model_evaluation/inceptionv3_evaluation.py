import os
import warnings

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

warnings.filterwarnings("ignore")

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import os

from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.applications.? import ?, preprocess_input, decode_predictions # Sinh vien hoan thanh cac import cho model InceptionV3
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.layers import Lambda, Input
from tensorflow.keras.models import Model

from art.estimators.classification import TensorFlowV2Classifier
from art.attacks.evasion import ProjectedGradientDescent

# --- Cau hinh ---
IMG_SIZE = (?, ?) # Sinh vien dien kich thuoc anh cho model InceptionV3
IMAGE_FOLDER = 'images_test/'
EPS_VALUES = [0.0, 0.1, 0.25, 0.5, 1.0, 1.5, 2.0]

# ==========================================
# Chuan bi model
# ==========================================
print("Dang tai model Inception_V3...")
base_model = ?(weights="imagenet") # Sinh vien dien ten model da import

inputs = Input(shape=(?, ?, 3)) # Kich thuoc anh
x = Lambda(lambda img_data: preprocess_input(tf.cast(img_data, tf.float32)))(inputs)
outputs = base_model(x)
model = Model(inputs, outputs)

classifier = TensorFlowV2Classifier(
    model=model,
    nb_classes=1000,
    input_shape=(?, ?, 3), # Kich thuoc anh
    loss_object=CategoricalCrossentropy(from_logits=False),
    clip_values=(0, 255)
)

# ==========================================
# Load du lieu
# ==========================================
print(f"Dang load anh tu folder {IMAGE_FOLDER}...")

image_list = []
image_names = [] # Luu ten file de in ra cho de nhin
valid_files = [f for f in os.listdir(IMAGE_FOLDER)]


for img_name in valid_files:
    path = os.path.join(IMAGE_FOLDER, img_name)
    img = load_img(path, target_size=IMG_SIZE)
    img_arr = img_to_array(img)
    image_list.append(img_arr)
    image_names.append(img_name)

x_test = np.array(image_list)
print(f"-> Da load thanh cong {len(x_test)} anh.")

# Lay du doan goc (Clean Predictions)
preds_clean = classifier.predict(x_test)
decoded_clean = decode_predictions(preds_clean, top=1)
y_test = np.argmax(preds_clean, axis=1)

# ==========================================
# Thuc hien tan cong va in chi tiet
# ==========================================
print(f"Bat dau chay thu nghiem voi cac Epsilon...")

accuracy_results = []
avg_conf_wrong_results = []

for eps in EPS_VALUES:
    print(f"\n" + "="*40)
    print(f"--- TESTING EPSILON = {eps} ---")
    print("="*40)

    if eps == 0.0:
        # Voi Eps=0, in ra du doan hien tai (anh goc)
        print("Chi tiet du doan (Anh goc):")
        for i in range(len(x_test)):
            label_name = decoded_clean[i][0][1]
            prob = decoded_clean[i][0][2]
            print(f"  [{image_names[i]}] -> {label_name} ({prob*100:.2f}%)")

        accuracy_results.append(100.0)
        avg_conf_wrong_results.append(0.0)
        continue

    # --- Tan cong ---
    attacker = ProjectedGradientDescent(
        estimator=classifier,
        norm=np.inf,
        eps=eps,
        eps_step=eps/5,
        max_iter=20,
        targeted=False,
        verbose=False
    )

    x_adv = attacker.generate(x=x_test)

    # --- Du doan tren anh doi khang ---
    preds_adv = classifier.predict(x_adv)
    y_pred_adv = np.argmax(preds_adv, axis=1)
    decoded_adv = decode_predictions(preds_adv, top=1)

    # --- In chi tiet tung anh ---
    print("Chi tiet thay doi du doan:")
    for i in range(len(x_test)):
        # Thong tin anh goc
        orig_label = decoded_clean[i][0][1]
        orig_prob = decoded_clean[i][0][2]

        # Thong tin anh doi khang
        adv_label = decoded_adv[i][0][1]
        adv_prob = decoded_adv[i][0][2]

        # Kiem tra dung/sai
        is_correct = (y_pred_adv[i] == y_test[i])
        status = "OK" if is_correct else "Bi lua"

        # In ra dong so sanh
        print(f"  [{image_names[i]}] {orig_label} ({orig_prob*100:.2f}%) "
              f"-> {adv_label} ({adv_prob*100:.2f}%) [{status}]")

    # --- Tinh toan chi so tong hop ---
    acc = np.mean(y_pred_adv == y_test)
    accuracy_results.append(acc * 100)

    wrong_indices = np.where(y_pred_adv != y_test)[0]
    if len(wrong_indices) > 0:
        wrong_confs = np.max(preds_adv[wrong_indices], axis=1)
        mean_conf = np.mean(wrong_confs)
    else:
        mean_conf = 0.0
    avg_conf_wrong_results.append(mean_conf * 100)

    print(f"\n---> Ket qua tong hop Eps {eps}: Accuracy = {acc*100:.2f}%, Avg Conf (khi sai) = {mean_conf*100:.2f}%")

# ==========================================
# Ve bieu do
# ==========================================
plt.plot(EPS_VALUES, accuracy_results, marker='o', linewidth=2, label='InceptionV3')
plt.title(f"Robustness Curve")
plt.xlabel("Epsilon")
plt.ylabel("Accuracy (%)")
plt.grid(True)
plt.legend()
plt.savefig("robustness_curve_inceptionv3.png")
