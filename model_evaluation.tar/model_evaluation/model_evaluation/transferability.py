import os
import warnings

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

warnings.filterwarnings("ignore")

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img, img_to_array

from art.estimators.classification import TensorFlowV2Classifier
from art.attacks.evasion import ProjectedGradientDescent

# Import cho ResNet50
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input as preprocess_resnet, decode_predictions
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.layers import Lambda
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input

# Import cho VGG16
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input as preprocess_vgg

print("Dang tai model ResNet50 (pre-trained)...")
base_model = ResNet50(weights="imagenet")

# Tien xu li anh
IMG_SIZE = (224, 224)
image_path = 'images_test/dog.jpg'

img = load_img(image_path, target_size=IMG_SIZE)
image_for_attack = img_to_array(img)
image_for_attack = np.expand_dims(image_for_attack, axis=0)

print("Tai anh va model hoan tat.")

# Tao model "Wrapper" voi Preprocessing

inputs = Input(shape=(224, 224, 3))
x = Lambda(lambda img_data: <Ham preprocess cua ResNet50>(tf.cast(img_data, tf.float32)))(inputs) # Sinh vien dien ham preprocess cua ResNet50
outputs = base_model(x)
model = Model(inputs, outputs)

# Chuan bi ART Classifier

classifier = TensorFlowV2Classifier(
    model=model,
    nb_classes=1000,
    input_shape=(224, 224, 3),
    loss_object=CategoricalCrossentropy(from_logits=False),
    clip_values=(0, 255)
)

# Khoi tao va chay tan cong PGD

attack = ProjectedGradientDescent(
    estimator=classifier,
    norm=np.inf,
    eps=2.0,
    eps_step=0.4,
    max_iter=5,
    targeted=False
)

print("Bat dau tan cong PGD (co the mat mot chut thoi gian)...")
# Tao anh adversarial
adv_image_batch = attack.generate(x=image_for_attack)
print("Tan cong hoan tat.")

print("Dang tai VGG16...")
vgg_model = VGG16(weights="imagenet")

# Ham ho tro du doan an toan (khong lam hong du lieu goc)
def get_prediction(model, image_batch, preprocess_func):
    img_copy = image_batch.copy()
    img_pre = preprocess_func(img_copy)

    # Du doan
    preds = model.predict(img_pre, verbose=0)
    decoded = decode_predictions(preds, top=1)[0][0]
    return decoded[1], decoded[2]*100

# Lay ket qua du doan
# ResNet50 (Source)
res_label_clean, res_conf_clean = get_prediction(<resnet_model>, <anh goc>, <ham preprocess cua resnet>)
res_label_adv, res_conf_adv = get_prediction(<resnet_model>, <anh doi khang>, <ham preprocess cua resnet>)

# VGG16 (Target)
vgg_label_clean, vgg_conf_clean = get_prediction(<vgg_model>, <anh goc>, <ham preprocess cua vgg>)
vgg_label_adv, vgg_conf_adv = get_prediction(<vgg_model>, <anh doi khang>, <ham preprocess cua vgg>)

print("-" * 70)

# ResNet50
print("ResNet50 (Source)")
print(f"Goc: {res_label_clean} ({res_conf_clean:.2f}%)")
print(f"Doi khang: {res_label_adv} ({res_conf_adv:.2f}%)") 
print("-" * 70)

# VGG16
print("VGG16 (Target)")
print(f"Goc: {vgg_label_clean} ({vgg_conf_clean:.2f}%)")
print(f"Doi khang: {vgg_label_adv} ({vgg_conf_adv:.2f}%)") 
print("-" * 70)

# Truc quan hoa
plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(image_for_attack[0].astype('uint8'))
plt.title(f"Anh goc\nResNet: {res_label_clean} ({res_conf_clean:.2f}%)\nVGG16: {vgg_label_clean} ({vgg_conf_clean:.2f}%)")
plt.axis('off')

plt.subplot(1, 2, 2)
adv_show = np.clip(adv_image_batch[0], 0, 255).astype('uint8')
plt.imshow(adv_show)
plt.title(f"Anh doi khang\nResNet: {res_label_adv} ({res_conf_adv:.2f}%)\nVGG16: {vgg_label_adv} ({vgg_conf_adv:.2f}%)")
plt.axis('off')
plt.savefig("result_transfer.png")

'''
# =============================================================================
# Tan cong nguoc (Reverse Attack: VGG16 -> ResNet50)
# =============================================================================
print("\n" + "="*70)
print("Thuc hien tan cong nguoc: Dung VGG de tan cong ResNet50 ".center(70, "-"))
print("="*70)

# Tao Wrapper cho VGG16
vgg_input_layer = Input(shape=(224, 224, 3))
vgg_preprocess_layer = Lambda(lambda x: <Ham preprocess cua VGG16>(tf.cast(x, tf.float32)))(vgg_input_layer) # Sinh vien dien ham preprocess cua VGG16
vgg_output_layer = vgg_model(vgg_preprocess_layer)
vgg_wrapper = Model(vgg_input_layer, vgg_output_layer)

# Tao ART Classifier cho VGG16
vgg_classifier = TensorFlowV2Classifier(
    model=vgg_wrapper,
    nb_classes=1000,
    input_shape=(224, 224, 3),
    loss_object=CategoricalCrossentropy(from_logits=False),
    clip_values=(0, 255)
)

print("-> Dang tao anh doi khang tu VGG16...")
vgg_attack = ProjectedGradientDescent(
    estimator=vgg_classifier,
    norm=np.inf,
    eps=2.0,     
    eps_step=0.4,
    max_iter=5,
    targeted=False,
    verbose=False
)

adv_img_from_vgg = vgg_attack.generate(x=image_for_attack)

# Kiem tra cheo
print("-> Danh gia tren VGG16 (Source):")
lbl_vgg_self, conf_vgg_self = get_prediction(vgg_model, adv_img_from_vgg, preprocess_vgg)
print(f"   Ket qua: {lbl_vgg_self} ({conf_vgg_self:.2f}%)")

print("-> Danh gia tren ResNet50 (Target):")
lbl_resnet_cross, conf_resnet_cross = get_prediction(base_model, adv_img_from_vgg, preprocess_resnet)
print(f"   Ket qua: {lbl_resnet_cross} ({conf_resnet_cross:.2f}%)")

# Hien thi anh nhieu tao boi VGG16
plt.figure(figsize=(5, 5))
plt.imshow(np.clip(adv_img_from_vgg[0], 0, 255).astype('uint8'))
plt.title(f"Adv Image (Source: VGG16)\nPred by ResNet: {lbl_resnet_cross}")
plt.axis('off')
plt.savefig("adversarial_by_vgg")
'''
