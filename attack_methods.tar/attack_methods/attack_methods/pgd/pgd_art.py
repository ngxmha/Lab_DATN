import os
import warnings

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

warnings.filterwarnings("ignore")

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.preprocessing.image import load_img, img_to_array

from art.estimators.classification import TensorFlowV2Classifier
from art.attacks.evasion import ProjectedGradientDescent

from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input, decode_predictions
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.layers import Lambda
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input

# --- Tai model pre_trained va anh ---

print("Dang tai model ResNet50 (pre-trained)...")
base_model = ResNet50(weights="imagenet")

# Tai va tien xu li anh
IMG_SIZE = (224, 224)
image_path = '../dog.jpg'

img = load_img(image_path, target_size=IMG_SIZE)
image_for_attack = img_to_array(img)
image_for_attack = np.expand_dims(image_for_attack, axis=0)

print("Tai anh va model hoan tat.")

# --- Tao model "Wrapper" voi preprocessing --- 

inputs = Input(shape=(224, 224, 3))
x = Lambda(lambda img_data: preprocess_input(tf.cast(img_data, tf.float32)))(inputs)
outputs = base_model(x)
model = Model(inputs, outputs)

# --- Chuan bi ART classifier ---

classifier = TensorFlowV2Classifier(
    model=model,
    nb_classes=1000,
    input_shape=(224, 224, 3),
    loss_object=CategoricalCrossentropy(from_logits=False),
    clip_values=(0, 255)
)

# --- Khoi tao va chay tan cong PGD ---

target_label = np.zeros((1, 1000))
target_label[0, 250] = 1 # Siberian husky

# Khoi tao phuong thuc tan cong PGD
attack = ProjectedGradientDescent(
    estimator=classifier,
    norm=np.inf,
    eps=2.0,             # Gioi han nhieu
    eps_step=0.5,        # Kich thuoc buoc nhay trong moi vong lap
    max_iter=2,         # So vong lap
    targeted=False
)

print("Bat dau tan cong PGD (co the mat mot chut thoi gian)...")
# Tao anh adversarial
adv_image_batch = attack.generate(x=image_for_attack)
print("Tan cong hoan tat.")

# --- So sanh va truc quan hoa ket qua ---

pred_original_probs = classifier.predict(image_for_attack)
pred_adv_probs = classifier.predict(adv_image_batch)

decoded_original = decode_predictions(pred_original_probs, top=1)[0][0]
decoded_adv = decode_predictions(pred_adv_probs, top=1)[0][0]

label_original = decoded_original[1]
confidence_original = decoded_original[2] * 100
label_adv = decoded_adv[1]
confidence_adv = decoded_adv[2] * 100

# Tinh toan nhieu
perturbation = adv_image_batch - image_for_attack
l_inf_norm = np.max(np.abs(perturbation))

print(f"\n--- Ket qua ---")
print(f"Nhan goc (du doan): {label_original} ({confidence_original:.2f}%)")
print(f"Nhan doi khang (du doan): {label_adv} ({confidence_adv:.2f}%)")
print(f"Do lon nhieu (L-infinity Norm): {l_inf_norm:.4f}")


# Luu anh
plt.figure(figsize=(15, 6))

plt.subplot(1, 3, 1)
plt.imshow(image_for_attack[0].astype('uint8'))
plt.title(f"Anh goc\nDu doan: {label_original} ({confidence_original:.2f}%)", fontsize=14)
plt.axis('off')

plt.subplot(1, 3, 2)
adv_img_to_show = np.clip(adv_image_batch[0], 0, 255).astype('uint8')
plt.imshow(adv_img_to_show)
plt.title(f"Anh doi khang (PGD)\nDu doan: {label_adv} ({confidence_adv:.2f}%)", fontsize=14)
plt.axis('off')

plt.subplot(1, 3, 3)
noise_visual = perturbation[0]
noise_visual = (noise_visual - noise_visual.min()) / (noise_visual.max() - noise_visual.min())
plt.imshow(noise_visual)
plt.title(f"Nhieu L-inf (Norm:{l_inf_norm:.4f})", fontsize=14)
plt.axis('off')

plt.tight_layout()
plt.savefig("pgd_attack.png")
