import os
import warnings

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

warnings.filterwarnings("ignore")

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# --- Import cac thu vien can thiet ---
from art.estimators.classification import TensorFlowV2Classifier
from art.estimators.classification import BlackBoxClassifier
from art.attacks.evasion import HopSkipJump, DeepFool

from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input, decode_predictions
from tensorflow.keras.applications.resnet50 import decode_predictions
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.layers import Lambda, Input
from tensorflow.keras.models import Model
from tensorflow.keras.utils import load_img, img_to_array

# --- Tai model va anh ---

print("Dang tai model ResNet50 va anh...")
base_model = ResNet50(weights="imagenet")
IMG_SIZE = (224, 224)
image_path = 'dog.jpg'
img_keras = load_img(image_path, target_size=IMG_SIZE)
image_for_attack = img_to_array(img_keras)
image_for_attack = np.expand_dims(image_for_attack, axis=0)

# Tao model "Wrapper" voi Preprocessing
inputs = Input(shape=(224, 224, 3))
x = Lambda(lambda img_data: preprocess_input(tf.cast(img_data, tf.float32)))(inputs)
outputs = base_model(x)
model = Model(inputs, outputs)

# --- Dinh nghia ham du doan "API" Black-Box ---
# Day la "API" cua chung ta. No chi nhan anh tho (0-255)
# va tra ve xac suat (probabilities).
# No khong de lo bat cu thu gi ve gradient hay loss.

def black_box_predict_api(raw_images_batch: np.ndarray) -> np.ndarray:
    """
    Mo phong mot API black-box.
    - Dau vao: Batch anh numpy (0-255)
    - Dau ra: Batch xac suat (softmax)
    """
    print("   [API Call] Nhan duoc anh, dang xu ly va du doan...")
    probabilities = model.predict(raw_images_batch)
    results = decode_predictions(probabilities, top=3)[0]

    print("Top 3 du doan:")
    for i, (imagenet_id, label, score) in enumerate(results):
        print(f"{i + 1}: {label} ({score * 100:.2f}%)")
    return probabilities


# CLASSIFIER BLACK-BOX (Mo phong API)
# No chi nhan ham mo phong cua chung ta.
print("Dang tao Black-Box API Classifier...")
black_box_api_classifier = BlackBoxClassifier(
    predict_fn=black_box_predict_api, # Chi cung cap ham du doan
    input_shape=(224, 224, 3),
    nb_classes=1000,
    clip_values=(0, 255)
    # Khong he co 'model' hay 'loss_object'
)

# --- Thu nghiem ---

attack_df_black = DeepFool(classifier=black_box_api_classifier, max_iter=10)
adv_black = attack_df_black.generate(x=image_for_attack)

#attack_hsja_black = HopSkipJump(classifier=black_box_api_classifier, max_iter=25, max_eval=500, init_eval=100)
#adv_black = attack_hsja_black.generate(x=image_for_attack)

# --- Kiem tra ket qua ---

# Du doan tren anh goc
pred_orig = model.predict(image_for_attack)
label_orig = decode_predictions(pred_orig, top=1)[0][0] # (id, name, score)

# Du doan tren anh doi khang
pred_adv = model.predict(adv_black)
label_adv = decode_predictions(pred_adv, top=1)[0][0]

# Tinh do nhieu - Xem anh bi thay doi bao
l2_noise = np.linalg.norm(adv_black - image_for_attack)

# In ket qua
print("-" * 30)
print(f"Ket qua tan cong HopSkipJump:")
print(f"Anh goc du doan la:      {label_orig[1]} ({label_orig[2]*100:.2f}%)")
print(f"Anh doi khang du doan la: {label_adv[1]} ({label_adv[2]*100:.2f}%)")
print(f"Do lon nhieu (L2 norm):   {l2_noise:.4f}")

if label_orig[1] != label_adv[1]:
    print("=> TAN CONG THANH CONG! (Mo hinh da bi lua)")
else:
    print("=> Tan cong that bai (Hoac can tang max_iter/max_eval)")
print("-" * 30)

# Hien thi ket qua de so sanh

# Anh goc
plt.title(f"Original: {label_orig[1]}")
plt.imshow(image_for_attack[0].astype(np.uint8)) 
plt.axis('off')
plt.savefig("original.png")

# Anh doi khang
plt.title(f"Adversarial: {label_adv[1]}")
plt.imshow(adv_black[0].astype(np.uint8))
plt.axis('off')
plt.savefig("adversarial.png")
