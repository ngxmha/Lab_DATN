import os
import warnings

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

warnings.filterwarnings("ignore")

import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# --- Import cac thu vien can thiet ---
from art.estimators.classification import TensorFlowV2Classifier
from art.attacks.evasion import HopSkipJump 

from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input, decode_predictions
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.layers import Lambda, Input
from tensorflow.keras.models import Model
from tensorflow.keras.utils import load_img, img_to_array

# --- Tai model pre_trained va anh ---

print("Dang tai model ResNet50 (pre-trained)...")
base_model = ResNet50(weights="imagenet")

IMG_SIZE = (224, 224)
image_path = '../dog.jpg'

# Tai anh
img_keras = load_img(image_path, target_size=IMG_SIZE)
image_for_attack = img_to_array(img_keras) 
image_for_attack = np.expand_dims(image_for_attack, axis=0)

print("Tai anh va model hoan tat.")

# --- Tao model "Wrapper" voi Preprocessing  ---

inputs = Input(shape=(224, 224, 3))
x = Lambda(lambda img_data: preprocess_input(tf.cast(img_data, tf.float32)))(inputs)
outputs = base_model(x)
model = Model(inputs, outputs)

# --- Chuan bi ART Classifier  ---
classifier = TensorFlowV2Classifier(
    model=model,
    nb_classes=1000,
    input_shape=(224, 224, 3),
    loss_object=CategoricalCrossentropy(from_logits=False),
    clip_values=(0, 255) 
)

# --- Khoi tao va chay tan cong HopSkipJump ---

print("Khoi tao tan cong HopSkipJump...")
attack = HopSkipJump(
    classifier=classifier,
    max_iter=25,      # So vong lap toi uu hoa (giu thap de chay nhanh)
    max_eval=1000,    # Tong so lan "hoi" mo hinh (giu thap de chay nhanh)
    init_eval=100,     # So lan hoi de khoi tao
    verbose=True      # Bat log de xem tien trinh
)

print("Bat dau tan cong HopSkipJump (se mat thoi gian)...")
# HopSkipJump se goi classifier.predict() hang nghin lan
adv_image_batch = attack.generate(x=image_for_attack)
print("Tan cong hoan tat.")

# --- So sanh va truc quan hoa ket qua ---

pred_original_probs = classifier.predict(image_for_attack)
pred_adv_probs = classifier.predict(adv_image_batch)

decoded_original = decode_predictions(pred_original_probs, top=1)[0][0]
decoded_adv = decode_predictions(pred_adv_probs, top=1)[0][0]

label_original = decoded_original[1]
confidence_original = decoded_original[2] * 100
label_adv = decoded_adv[1]
confidence_adv = decoded_adv[2] * 100

# Tinh toan nhieu
perturbation = adv_image_batch - image_for_attack
l2_norm = np.linalg.norm(perturbation)

print(f"\n--- Ket qua (HopSkipJump) ---") 
print(f"Nhan goc (du doan): {label_original} ({confidence_original:.2f}%)")
print(f"Nhan doi khang(du doan): {label_adv} ({confidence_adv:.2f}%)")
print(f"Do lon nhieu (L2 Norm): {l2_norm:.4f}")

# Luu anh
plt.figure(figsize=(15, 6))

plt.subplot(1, 3, 1)
plt.imshow(np.clip(image_for_attack[0], 0, 255).astype('uint8'))
plt.title(f"Anh goc\nDu doan: {label_original} ({confidence_original:.2f}%)", fontsize=14)
plt.axis('off')

plt.subplot(1, 3, 2)
adv_img_to_show = np.clip(adv_image_batch[0], 0, 255).astype('uint8')
plt.imshow(adv_img_to_show)
plt.title(f"Anh doi khang (HopSkipJump)\nDu doan: {label_adv} ({confidence_adv:.2f}%)", fontsize=14)
plt.axis('off')

plt.subplot(1, 3, 3)
noise_visual = perturbation[0]
noise_visual = (noise_visual - noise_visual.min()) / (noise_visual.max() - noise_visual.min())
plt.imshow(noise_visual)
plt.title(f"Nhieu L2 (Norm: {l2_norm:.4f})", fontsize=14)
plt.axis('off')

plt.tight_layout()
plt.savefig("hopskipjump_attack.png")
